package com.example.admin.quanLyThuVien.interfaces;

public interface ILoadmore {
    void onLoadMore();
}
